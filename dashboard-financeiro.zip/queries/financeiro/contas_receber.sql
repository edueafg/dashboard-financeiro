-- Contas a Receber - RP Decalc
-- Análise de clientes com atraso

SELECT
    c.razao_social as cliente,
    COUNT(cr.id) as quantidade_titulos,
    SUM(cr.valor_documento) as valor_total,
    SUM(CASE WHEN cr.data_vencimento < CURRENT_DATE AND cr.situacao = 'ABERTO'
        THEN cr.valor_documento ELSE 0 END) as valor_em_atraso,
    DATEDIFF(DAY, MAX(cr.data_vencimento), CURRENT_DATE) as dias_atraso,
    CASE
        WHEN SUM(CASE WHEN cr.data_vencimento < CURRENT_DATE AND cr.situacao = 'ABERTO'
            THEN cr.valor_documento ELSE 0 END) > 0 THEN '⚠️ ATRASO'
        ELSE '✅ EM DIA'
    END as status
FROM contas_receber cr
INNER JOIN clientes c ON cr.cliente_id = c.id
WHERE cr.situacao = 'ABERTO'
    AND cr.data_vencimento <= CURRENT_DATE + 30
GROUP BY c.id, c.razao_social
ORDER BY valor_em_atraso DESC, dias_atraso DESC

-- Contas a Pagar - RP Decalc
-- Análise de fornecedores

SELECT
    f.razao_social as fornecedor,
    COUNT(cp.id) as quantidade_titulos,
    SUM(cp.valor_documento) as valor_total,
    SUM(CASE WHEN cp.data_vencimento < CURRENT_DATE AND cp.situacao = 'ABERTO'
        THEN cp.valor_documento ELSE 0 END) as valor_vencido,
    SUM(CASE WHEN cp.data_vencimento BETWEEN CURRENT_DATE AND CURRENT_DATE + 30
        AND cp.situacao = 'ABERTO' THEN cp.valor_documento ELSE 0 END) as valor_30dias,
    CASE
        WHEN SUM(CASE WHEN cp.data_vencimento < CURRENT_DATE AND cp.situacao = 'ABERTO'
            THEN cp.valor_documento ELSE 0 END) > 0 THEN '⚠️ VENCIDO'
        WHEN SUM(CASE WHEN cp.data_vencimento BETWEEN CURRENT_DATE AND CURRENT_DATE + 30
            AND cp.situacao = 'ABERTO' THEN cp.valor_documento ELSE 0 END) > 0 THEN '⏰ PRÓXIMO'
        ELSE '✅ EM DIA'
    END as status
FROM contas_pagar cp
INNER JOIN fornecedores f ON cp.fornecedor_id = f.id
WHERE cp.situacao = 'ABERTO'
    AND cp.data_vencimento <= CURRENT_DATE + 60
GROUP BY f.id, f.razao_social
ORDER BY valor_vencido DESC, valor_30dias DESC

-- Fluxo de Caixa Projetado - RP Decalc
-- Previsão para 30/60/90 dias

SELECT
    CASE
        WHEN DATEDIFF(DAY, CURRENT_DATE, data) <= 30 THEN '📊 0-30 dias'
        WHEN DATEDIFF(DAY, CURRENT_DATE, data) <= 60 THEN '📈 30-60 dias'
        ELSE '📉 60-90 dias'
    END as periodo,

    SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END) as entradas,
    SUM(CASE WHEN tipo = 'DESPESA' THEN valor ELSE 0 END) as saidas,
    SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE -valor END) as saldo_liquido

FROM (
    -- RECEITAS (Contas a Receber)
    SELECT
        data_vencimento as data,
        'RECEITA' as tipo,
        valor_documento as valor
    FROM contas_receber
    WHERE situacao = 'ABERTO'
        AND data_vencimento BETWEEN CURRENT_DATE AND CURRENT_DATE + 90

    UNION ALL

    -- DESPESAS (Contas a Pagar)
    SELECT
        data_vencimento as data,
        'DESPESA' as tipo,
        valor_documento as valor
    FROM contas_pagar
    WHERE situacao = 'ABERTO'
        AND data_vencimento BETWEEN CURRENT_DATE AND CURRENT_DATE + 90
) fluxo

GROUP BY
    CASE
        WHEN DATEDIFF(DAY, CURRENT_DATE, data) <= 30 THEN '📊 0-30 dias'
        WHEN DATEDIFF(DAY, CURRENT_DATE, data) <= 60 THEN '📈 30-60 dias'
        ELSE '📉 60-90 dias'
    END
ORDER BY periodo

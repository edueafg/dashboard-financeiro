-- DRE Mensal - RP Decalc
-- Demonstração de Resultado do Exercício
-- Customize com as tabelas reais do seu RP Decalc

SELECT
    MONTH(data) as mes,
    SUM(valor_receita) as receita,
    SUM(valor_custo) as custo,
    SUM(valor_despesa) as despesa,
    (SUM(valor_receita) - SUM(valor_custo) - SUM(valor_despesa)) as lucro_liquido
FROM (
    -- RECEITAS (NF de Saída)
    SELECT
        CAST(data_emissao as DATE) as data,
        total_nf as valor_receita,
        0 as valor_custo,
        0 as valor_despesa
    FROM nf_saida
    WHERE YEAR(data_emissao) = YEAR(CURRENT_DATE)

    UNION ALL

    -- CUSTOS (Detalhes de NF - COGS)
    SELECT
        CAST(data_emissao as DATE) as data,
        0 as valor_receita,
        (quantidade * valor_custo_unitario) as valor_custo,
        0 as valor_despesa
    FROM nf_saida_det
    WHERE YEAR(data_emissao) = YEAR(CURRENT_DATE)

    UNION ALL

    -- DESPESAS (Contas a Pagar)
    SELECT
        CAST(data_vencimento as DATE) as data,
        0 as valor_receita,
        0 as valor_custo,
        valor_documento as valor_despesa
    FROM contas_pagar
    WHERE tipo_documento = 'DESPESA'
        AND YEAR(data_vencimento) = YEAR(CURRENT_DATE)
) dados
GROUP BY MONTH(data)
ORDER BY mes
